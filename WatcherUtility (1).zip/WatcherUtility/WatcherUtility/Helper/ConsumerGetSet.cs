﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;

namespace WatcherUtility.Helper
{
    [XmlRoot("meta-data")]
    public class ConsumerGetSet
    {
        [XmlElement("CustomerName")]
        public string CustomerName
        {
            get;
            set;
        }

        [XmlElement("SIN")]
        public string SIN
        {
            get;
            set;
        }
    }
}
