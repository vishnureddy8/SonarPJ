﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using System.Configuration;
using System.Collections.Specialized;
using WatcherUtility.Helper;
using System.Configuration;
using System.Collections;

namespace WatcherUtility
{
    public partial class Form1 : Form
    {
        #region GLobal Declarations
        //string NoOfUsers;
        //int tempUsers;
        //public bool MonitoringStatus;
        //public String Filename = "";
        //public String FileNameWithExtension = "";
        //public String Extension = "";
        //public String Xml = "";
        //string[] filenameproperties = new string[3];


        //Initializing Log File
        LogBase log = new LogBase();

        

        //Variables for assigning values from App.config file
        string errorDump;
        string backupDump;
        string BatchClassName;
        string BatchPriority;
        string FormName;
        string BatchPropertyOne;
        string BatchPropertyTwo;
        string BatchPropertyThree;
        string FormNameOne;
        string FormNameTwo;
        string FormNameThree;
        bool xmlProvided = false;



        // Create FolderBrowserDialog object.
        FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();


        #endregion

        public Form1()
        {
            InitializeComponent();
            //NoOfUsers = ConfigurationManager.AppSettings["No OF Users"];
            //Int32.TryParse("NoOfUsers", out tempUsers);
            
        }

       

        #region Browse Button
        private void button1_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.ShowNewFolderButton = true;
            DialogResult dialogResult = folderBrowserDialog.ShowDialog();
            if (dialogResult == DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog.SelectedPath))
            {

                textBox1.Text = folderBrowserDialog.SelectedPath;
                Environment.SpecialFolder root = folderBrowserDialog.RootFolder;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.ShowNewFolderButton = true;
            DialogResult dialogResult = folderBrowserDialog.ShowDialog();
            if (dialogResult == DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog.SelectedPath))
            {

                textBox2.Text = folderBrowserDialog.SelectedPath;
                Environment.SpecialFolder root = folderBrowserDialog.RootFolder;
            }
        }
        #endregion

        #region Start Monitoring Button
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var monitoringFilesLocation = new List<string>();
                var monitoringFiles = ConfigurationManager.GetSection("MonitoringFolders") as NameValueCollection;
                if (monitoringFiles.Count == 0)
                {
                    log.LogFileWrite("Invalid Section");
                }
                else
                {
                    foreach (var key in monitoringFiles.AllKeys)
                    {
                        monitoringFilesLocation.Add(monitoringFiles[key]);
                    }
                }

                ArrayList aFileWatcherInstance = new ArrayList();
                foreach (string sMonitorFolder in monitoringFilesLocation)
                {
                    //Check if Directory Exisits
                    if (Directory.Exists(sMonitorFolder))
                    {
                        // Create a new FileSystemWatcher object.
                        FileSystemWatcher fsWatcher = new FileSystemWatcher();

                        fsWatcher.Path = sMonitorFolder;

                        //Set the Filter Expression.
                        fsWatcher.Filter ="*.*";

                        //MonitoringStatus = true;


                        fsWatcher.IncludeSubdirectories = true;
                        // Monitor all changes specified in the NotifyFilters.
                        fsWatcher.NotifyFilter = NotifyFilters.Attributes |
                                                 NotifyFilters.CreationTime |
                                                 NotifyFilters.DirectoryName |
                                                 NotifyFilters.FileName |
                                                 NotifyFilters.LastAccess |
                                                 NotifyFilters.LastWrite |
                                                 NotifyFilters.Security |
                                                 NotifyFilters.Size;

                        fsWatcher.IncludeSubdirectories = true;


                        fsWatcher.Changed += new FileSystemEventHandler(OnChanged);
                        fsWatcher.Created += new FileSystemEventHandler(OnCreated);
                        fsWatcher.Renamed += new RenamedEventHandler(OnRenamed);
                        fsWatcher.Error += new ErrorEventHandler(OnError);

                        // Raise Event handlers.
                        fsWatcher.EnableRaisingEvents = true;

                        
                        //Add a new instance of FileWatcher 
                        aFileWatcherInstance.Add(fsWatcher);

                        log.LogFileWrite(DateTime.Now + " : File Watcher Started" +fsWatcher);
                        log.LogFileWrite(aFileWatcherInstance.ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                log.LogFileWrite("Null User Value: " + ex.Message);
            }

            
            
        }

        #endregion

        #region Event Handlers of File SystemWatcher

        // FileSystemWatcher – OnCreated Event Handler
        public void OnCreated(object sender, FileSystemEventArgs e)
        {
            log.LogFileWrite(DateTime.Now+" : On Created Method was called");
            string path = e.Name;
            e.GetType();
            e.GetHashCode();
            this.Invoke(new Action(() => findConsumer(e.FullPath))); 
            this.Invoke(new Action(() => processFile(e.FullPath)));
            //string[] files = Directory.GetFiles(e.FullPath);
            //log.LogFileWrite(DateTime.Now + e.FullPath);
            //this.Invoke(new Action(() => CreateXML()));
        }


        // FileSystemWatcher – OnChanged Event Handler
        public void OnChanged(object sender, FileSystemEventArgs e)
        {

            this.Invoke(new Action(() => log.LogFileWrite("On Changed Method was called")));
            log.LogFileWrite(DateTime.Now + e.FullPath);
            this.Invoke(new Action(() => processFile(e.FullPath)));
        }


        // FileSystemWatcher – OnRenamed Event Handler
        public void OnRenamed(object sender, RenamedEventArgs e)
        {

            this.Invoke(new Action(() => log.LogFileWrite("On Renamed Method was called")));
            log.LogFileWrite(DateTime.Now + e.FullPath);
            //this.Invoke(new Action(() => CreateXML()));
        }





        public void OnError(object sender, ErrorEventArgs e)
        {
            // Add event details in listbox.
            //this.Invoke((MethodInvoker)delegate { listBox1.Items.Add(String.Format("Error : {0}”", e.GetException().Message)); });
        }
        #endregion

        #region Processing Files

        public void processFile(string filepath)
        {
            try
            {
                #region finding which types of files to Monitor
                //Adding up all file types in a list from Config file
                var fileExtensions = new List<string>();
                var fileTypes = ConfigurationManager.GetSection("FileType") as NameValueCollection;
                if (fileTypes.Count == 0)
                {
                    log.LogFileWrite("Invalid Section");
                }
                else
                {
                    foreach (var key in fileTypes.AllKeys)
                    {
                        fileExtensions.Add(fileTypes[key]);
                    }
                }
                #endregion

                //Get File Extension
                string extentionForFile = Path.GetExtension(filepath);

                //if File Type is one of the files to Monitor then proceed or go to Else
                if (fileExtensions.Contains(extentionForFile))
                {
                    if (extentionForFile == "xml")
                    {
                        xmlProvided = true;
                        createTargetFile(filepath);
                        

                    }
                    else
                    {
                        MoveFileToOtherDirectory(filepath, backupDump);
                    }

                }

                //File Type to monitor not defined in Config File
                else
                {
                    log.LogFileWrite("Invalid file Extension");
                    MoveFileToOtherDirectory(filepath, errorDump);

                }
            }
            catch(Exception e)
            {
                log.LogFileWrite(e.Message);
            }
            finally
            {
                if(xmlProvided==false)
                {

                }
                else
                {
                    log.LogFileWrite("Input XMl file was provided");

                }

            }
        }
        #endregion


        

        #region CreateXML method
        //public void CreateXML()
        //{
        //    string[] files = Directory.GetFiles(folderBrowserDialog.SelectedPath);
        //    System.Windows.Forms.MessageBox.Show("Files found: " + files.Length.ToString(), "Message");
        //    var fileExtensions = new List<string>();
        //    var fileTypes = ConfigurationManager.GetSection("FileType") as NameValueCollection;
        //    if (fileTypes.Count == 0)
        //    {
        //        log.LogFileWrite("Invalid Section");
        //    }
        //    else
        //    {
        //        foreach (var key in fileTypes.AllKeys)
        //        {
        //            fileExtensions.Add(fileTypes[key]);
        //        }
        //    }

        //    for (int i = 0; i < files.Length; i++)
        //    {
        //        string extentionForFile = Path.GetExtension(files[i]);
        //        Filename = Path.GetFileNameWithoutExtension(files[i]);
        //        FileNameWithExtension = Path.GetFileName(files[i]);
        //        if (fileExtensions.Contains(extentionForFile))
        //        {
        //            try
        //            {
        //                log.LogFileWrite("------------------------------------------------------------------------------------");
        //                log.LogFileWrite("Processing File " + FileNameWithExtension + "   " + DateTime.Now);
        //                filenameproperties = Filename.Split('_');

                        
        //                #region if file name format is incorrect and already processed

        //                string[] IncorrectFileNameFiles = Directory.GetFiles(ConfigurationManager.AppSettings["Incorrect File Name"]);

        //                foreach (string element in IncorrectFileNameFiles)
        //                {
        //                    if (element.Split('\\').Last().ToString() == FileNameWithExtension)
        //                    {
        //                        File.Delete(ConfigurationManager.AppSettings["Incorrect File Name"] + "\\" + FileNameWithExtension);
        //                        MoveFileToOtherDirectory(textBox1.Text, ConfigurationManager.AppSettings["Incorrect File Name"]);
        //                        log.LogFileWrite(files[i] + " was already Processed and moved to Incorrect File Name folder. Deleting existing file from Monitoring Folder");
        //                    }
        //                }
        //                #endregion

        //                #region if file name format is correct

        //                string[] SuccessfullyProcessedFiles = Directory.GetFiles(ConfigurationManager.AppSettings["Succefully Processed Files XML"]);

        //                //If Null value comes for SuccessfullyProcessedFiles
        //                if (SuccessfullyProcessedFiles.Count() == 0)
        //                {
        //                    XmlDocument document = new XmlDocument();
        //                    document.LoadXml(string.Format(@"<rpmi><PPNO>{0}</PPNO><PPNAME>{1}</PPNAME><CORRNO>{2}</CORRNO></rpmi>", filenameproperties[0], filenameproperties[1],
        //                        filenameproperties[2]));
        //                    var nodeList = document.SelectNodes("rpmi");
        //                    document.Save(ConfigurationManager.AppSettings["Succefully Processed Files XML"] + filenameproperties[2]);
        //                    MoveFileToOtherDirectory(textBox1.Text, ConfigurationManager.AppSettings["Successfully Processed Original Files"]);
        //                }

        //                foreach (string element in SuccessfullyProcessedFiles)
        //                {
        //                    string[] lastElement = element.Split('\\');
        //                    if (filenameproperties.Last() == lastElement.Last())
        //                    {
        //                        File.Delete(ConfigurationManager.AppSettings["Incorrect File Name"] + FileNameWithExtension);
        //                        log.LogFileWrite(files[i] + " was already Processed and moved to Successfully Processed folder. Deleting existing file from Monitoring Folder");
        //                    }

        //                    else
        //                    {
        //                        XmlDocument document = new XmlDocument();
        //                        document.LoadXml(
        //                            string.Format(@"<rpmi><PPNO>{0}</PPNO><PPNAME>{1}</PPNAME><CORRNO>{2}</CORRNO></rpmi>",
        //                            filenameproperties[0], filenameproperties[1],
        //                            filenameproperties[2]));
        //                        var nodeList = document.SelectNodes("rpmi");
        //                        document.Save(ConfigurationManager.AppSettings["Succefully Processed Files XML"] + filenameproperties[2]);
        //                        MoveFileToOtherDirectory(textBox1.Text,
        //                            ConfigurationManager.AppSettings["Successfully Processed Original Files"]);
        //                    }

        //                }
        //                #endregion
        //            }

        //            catch (Exception e)
        //            {

        //                log.LogFileWrite(e.Message);
        //                MoveFileToOtherDirectory(textBox1.Text, ConfigurationManager.AppSettings["Incorrect File Name"]);
        //            }
        //        }
        //        else
        //        {
        //            log.LogFileWrite("------------------------------------------------------------------------------------");
        //            log.LogFileWrite("Processing File " + FileNameWithExtension + "   " + DateTime.Now);
        //            log.LogFileWrite("Invalid file extension to process");
        //            MoveFileToOtherDirectory(textBox1.Text, ConfigurationManager.AppSettings["Incorrect File Name"]);
        //        }
        //    }
        //}


        private void MoveFileToOtherDirectory(string source, string target)
        {
            try
            {
                // Get the subdirectories for the specified directory.
                DirectoryInfo dir = new DirectoryInfo(source);

                if (!dir.Exists)
                {

                    log.LogFileWrite("Source directory does not exist or could not be found: " + source);
                }

                DirectoryInfo[] dirs = dir.GetDirectories();
                // If the destination directory doesn't exist, create it.
                if (!Directory.Exists(target))
                {
                    Directory.CreateDirectory(target);
                }

                //File.Move(source + "\\" + FileNameWithExtension, target + "\\" + FileNameWithExtension);
                File.Move(source, target);

            }
            catch (Exception ex)
            {
                log.LogFileWrite(ex.Message);
            }
        }

        #endregion

        #region XML validation

        public void validateXMLfromXSD()
        {
            XmlReader xmlReader = null;

            try
            {
                XmlReaderSettings validationSettings = new XmlReaderSettings();

                validationSettings.Schemas.Add("http://www.contoso.com/books", ConfigurationManager.AppSettings["XSD Location"]);
                log.LogFileWrite("---------------------------------------------------");
                log.LogFileWrite("---------------------------------------------------");
                log.LogFileWrite("validation of XML from XSD started");
                //XSD
                validationSettings.ValidationType = ValidationType.Schema;
                validationSettings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;

                validationSettings.ValidationEventHandler += new ValidationEventHandler(XMLtoXSDValidationEventHandler);


                //Validate XML with XSD
                xmlReader = XmlReader.Create("C:\\Users\\rahulbhasker\\Documents\\books.xml", validationSettings);

                //Itrate over XML
                while (xmlReader.Read()) { }
                log.LogFileWrite("Validation Passed");
                log.LogFileWrite("Validation Process Completed");
                log.LogFileWrite("--------------------------------------------------");
                log.LogFileWrite("--------------------------------------------------");

            }
            catch (Exception e)
            {
                log.LogFileWrite("Validation error : " + e.Message);
            }
            finally
            {
                xmlReader.Dispose();
            }


        }
  
        private void XMLtoXSDValidationEventHandler(object sender, ValidationEventArgs e)
        {
            log.LogFileWrite("Validation Error :" + e.Message);
            log.LogFileWrite("Validation Process Completed");
            log.LogFileWrite("--------------------------------------------------");
            log.LogFileWrite("--------------------------------------------------");
            throw new Exception("Validation Failde Message : "+e.Message);

        }
        #endregion

        #region Target File Creation
        public void createTargetFile(string inputFileLocation)
        {
            try
            {
                //Deserializing input XML
                XmlSerializer deserializingMetadataXML = new XmlSerializer(typeof(ConsumerGetSet));
                StreamReader sr = new StreamReader(inputFileLocation);
                ConsumerGetSet consumerobj = (ConsumerGetSet)deserializingMetadataXML.Deserialize(sr);
                

                List < TargetGetSet > trg= new List<TargetGetSet>();
                
                XmlSerializer serial = new XmlSerializer(typeof(List<TargetGetSet>));
                using (FileStream fs = new FileStream(backupDump, FileMode.Create, FileAccess.Write)) ;
                {

                }
                


            }
            catch(Exception e)
            {
                log.LogFileWrite("target File Method Error: "+e.Message);

            }

        }


        #endregion

        #region finding Consumer and allocating values
        public void findConsumer(string filepath)
        {
            string extentionForFile = Path.GetExtension(filepath);
            String ConsumerName = null;
            String[] substrings = filepath.Split('\\');
            int flag = 0;
            foreach (var substring in substrings)
            {
                if (substring.Contains("Consumer"))
                {
                    ConsumerName = substrings[flag];
                    log.LogFileWrite("Consumer Name : " + ConsumerName);
                }
                else
                {
                    flag++;
                }


            }

            var customerData = new List<string>();
            var Consumer = ConfigurationManager.GetSection(ConsumerName) as NameValueCollection;
            if (Consumer.Count == 0)
            {
                log.LogFileWrite("Invalid Section");
            }
            else
            {
                foreach (var key in Consumer.AllKeys)
                {
                    customerData.Add(Consumer[key]);
                }
            }

            backupDump = customerData[0];
            errorDump = customerData[1];
            BatchClassName = customerData[2];
            BatchPriority = customerData[3];
            FormName = customerData[4];
            BatchPropertyOne = customerData[5];
            BatchPropertyTwo = customerData[6];
            FormNameOne = customerData[7];
            FormNameTwo = customerData[8];
            FormNameThree = customerData[9];


        }
        #endregion





    }
}
