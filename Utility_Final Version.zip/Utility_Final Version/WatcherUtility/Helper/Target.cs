﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
using WatcherUtility.Helper;

namespace WatcherUtility.Helper
{

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public class ImportSession
    {

        private ImportSessionBatches batchesField;

        /// <remarks/>
        public ImportSessionBatches Batches
        {
            get
            {
                return this.batchesField;
            }
            set
            {
                this.batchesField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ImportSessionBatches
    {

        private ImportSessionBatchesBatch batchField;

        private ImportSessionBatchesBatchFields batchFieldsField;

        private ImportSessionBatchesDocuments documentsField;

        /// <remarks/>
        public ImportSessionBatchesBatch Batch
        {
            get
            {
                return this.batchField;
            }
            set
            {
                this.batchField = value;
            }
        }

        /// <remarks/>
        public ImportSessionBatchesBatchFields BatchFields
        {
            get
            {
                return this.batchFieldsField;
            }
            set
            {
                this.batchFieldsField = value;
            }
        }

        /// <remarks/>
        public ImportSessionBatchesDocuments Documents
        {
            get
            {
                return this.documentsField;
            }
            set
            {
                this.documentsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ImportSessionBatchesBatch
    {

        private string batchNameField;

        private int priorityField;

        private string batchClassNameField;

        /// <remarks/>
        public string BatchName
        {
            get
            {
                return this.batchNameField;
            }
            set
            {
                this.batchNameField = value;
            }
        }

        /// <remarks/>
        public int Priority
        {
            get
            {
                return this.priorityField;
            }
            set
            {
                this.priorityField = value;
            }
        }

        /// <remarks/>
        public string BatchClassName
        {
            get
            {
                return this.batchClassNameField;
            }
            set
            {
                this.batchClassNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ImportSessionBatchesBatchFields
    {

        private string b_FABSOFT_UNIQUE_IDField;

        private string b_FABSOFT_XML_DATETIMEField;

        private string b_MFD_DEVICE_NAMEField;

        private string b_MFD_IP_ADDRESSField;

        private string b_MFD_SERIAL_NOField;

        private string b_MFD_USER_IDField;

        /// <remarks/>
        public string B_FABSOFT_UNIQUE_ID
        {
            get
            {
                return this.b_FABSOFT_UNIQUE_IDField;
            }
            set
            {
                this.b_FABSOFT_UNIQUE_IDField = value;
            }
        }

        /// <remarks/>
        public string B_FABSOFT_XML_DATETIME
        {
            get
            {
                return this.b_FABSOFT_XML_DATETIMEField;
            }
            set
            {
                this.b_FABSOFT_XML_DATETIMEField = value;
            }
        }

        /// <remarks/>
        public string B_MFD_DEVICE_NAME
        {
            get
            {
                return this.b_MFD_DEVICE_NAMEField;
            }
            set
            {
                this.b_MFD_DEVICE_NAMEField = value;
            }
        }

        /// <remarks/>
        public string B_MFD_IP_ADDRESS
        {
            get
            {
                return this.b_MFD_IP_ADDRESSField;
            }
            set
            {
                this.b_MFD_IP_ADDRESSField = value;
            }
        }

        /// <remarks/>
        public string B_MFD_SERIAL_NO
        {
            get
            {
                return this.b_MFD_SERIAL_NOField;
            }
            set
            {
                this.b_MFD_SERIAL_NOField = value;
            }
        }

        /// <remarks/>
        public string B_MFD_USER_ID
        {
            get
            {
                return this.b_MFD_USER_IDField;
            }
            set
            {
                this.b_MFD_USER_IDField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ImportSessionBatchesDocuments
    {

        private string formTypeNameField;

        private ImportSessionBatchesDocumentsIndexFields indexFieldsField;

        private string[] pagesField;

       // private string[] textField;

        /// <remarks/>
        public string FormTypeName
        {
            get
            {
                return this.formTypeNameField;
            }
            set
            {
                this.formTypeNameField = value;
            }
        }

        /// <remarks/>
        public ImportSessionBatchesDocumentsIndexFields IndexFields
        {
            get
            {
                return this.indexFieldsField;
            }
            set
            {
                this.indexFieldsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("ImportFileName", IsNullable = false)]
        public string[] Pages
        {
            get
            {
                return this.pagesField;
            }
            set
            {
                this.pagesField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlTextAttribute()]
        //public string[] Text
        //{
        //    get
        //    {
        //        return this.textField;
        //    }
        //    set
        //    {
        //        this.textField = value;
        //    }
        //}
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ImportSessionBatchesDocumentsIndexFields
    {

        private string d_MFD_DOC_DATETIMEField;

        private string d_MFD_DOC_FORM_IDField;

        private string d_MFD_DOC_ACCT_NOField;

        private string d_MFD_DOC_BRANCH_NOField;

        /// <remarks/>
        public string D_MFD_DOC_DATETIME
        {
            get
            {
                return this.d_MFD_DOC_DATETIMEField;
            }
            set
            {
                this.d_MFD_DOC_DATETIMEField = value;
            }
        }

        /// <remarks/>
        public string D_MFD_DOC_FORM_ID
        {
            get
            {
                return this.d_MFD_DOC_FORM_IDField;
            }
            set
            {
                this.d_MFD_DOC_FORM_IDField = value;
            }
        }

        /// <remarks/>
        public string D_MFD_DOC_ACCT_NO
        {
            get
            {
                return this.d_MFD_DOC_ACCT_NOField;
            }
            set
            {
                this.d_MFD_DOC_ACCT_NOField = value;
            }
        }

        /// <remarks/>
        public string D_MFD_DOC_BRANCH_NO
        {
            get
            {
                return this.d_MFD_DOC_BRANCH_NOField;
            }
            set
            {
                this.d_MFD_DOC_BRANCH_NOField = value;
            }
        }
    }
}
