﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using System.Configuration;
using System.Collections.Specialized;
using WatcherUtility.Helper;
using System.Configuration;
using System.Collections;

namespace WatcherUtility
{
    public partial class Form1 : Form
    {
        #region GLobal Declarations
       
        long uniqueSeqId = 1234567891;
        //Initializing Log File
        LogBase log = new LogBase();

        String ConsumerName = null;

        List<string> subfoldersPath = new List<string>();



        //Variables for assigning values from App.config file
        string errorDump;
        string backupDump;
        string monitoringfolder;
        string logFileLocation;
        string BatchClassName;
        string BatchPriority;
        string FormName1;
        string FormName2;
        string B_CHANNEL;
        string B_BULK_INGESTION_XML_DATETIME;
        string B_BULK_INGESTION_SYTEM_NAME;

        string B_BULK_INGESTION_IP_ADDRESS;
        string B_BULK_INGESTION_SERIAL_NO;
        string B_BULK_INGESTION_USER_ID;

        string D_MFD_DOC_DATETIME;
        string D_MFD_DOC_FORM_ID;
        string D_MFD_DOC_ACCT_NO;
        string D_MFD_DOC_BRANCH_NO;


        string tempDump = ConfigurationManager.AppSettings["tempDump"];
       
        bool moveToErrorDump = false;
       
        int noOfInputXML = 0;
        StreamReader sr;
        StreamWriter swr;
        

        // Create FolderBrowserDialog object.
        FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();


        #endregion

        public Form1()
        {
            InitializeComponent();
            //Deserializing input XML
            
        }



        

        #region Start Monitoring Button
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var monitoringFilesLocation = new List<string>();
                var monitoringFiles = ConfigurationManager.GetSection("MonitoringFolders") as NameValueCollection;
                if (monitoringFiles.Count == 0)
                {
                    log.LogFileWrite(DateTime.Now+" : No monitoring FOlders location given in App.Config", ConfigurationManager.AppSettings["watcherLogFileLocation"]);
                }
                else
                {
                    foreach (var key in monitoringFiles.AllKeys)
                    {
                        monitoringFilesLocation.Add(monitoringFiles[key]);
                    }
                }

                //Creating a text file for reading unique sequence ID

                try
                {
                    string line;

                    if (File.Exists(ConfigurationManager.AppSettings["UniqueRefCounterFileLocation"]))
                    {
                        
                        //Pass the file path and file name to the StreamReader constructor
                        StreamReader sr = new StreamReader(ConfigurationManager.AppSettings["UniqueRefCounterFileLocation"]);

                        //Read the first line of text
                        line = sr.ReadLine();

                        //Continue to read until you reach end of file
                        
                            uniqueSeqId = long.Parse(line);
                            uniqueSeqId = uniqueSeqId + 1;
                       
                        sr.Close();
                        File.WriteAllText(ConfigurationManager.AppSettings["UniqueRefCounterFileLocation"], uniqueSeqId.ToString());

                        

                    }
                    else
                    {
                        File.WriteAllText(ConfigurationManager.AppSettings["UniqueRefCounterFileLocation"], uniqueSeqId.ToString());
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception: " + ex.Message);
                }

                //Checking each Monitoring Folder

                foreach (string sMonitorFolder in monitoringFilesLocation)
                {
                    //Check if Directory Exisits
                    if (Directory.Exists(sMonitorFolder))
                    {
                        //Finding Consumer Sprecefic values Who ownes the monitoring Folder
                        findConsumer(sMonitorFolder);

                        //Getting list of all folders inside Monitoring folder
                        subfoldersPath = Directory.GetDirectories(sMonitorFolder).ToList();

                        //Processing each folder
                        foreach(var subfolderPath in subfoldersPath)
                        {
                            processFolder(subfolderPath);

                            if(moveToErrorDump==true)
                            {
                                string source = tempDump + subfolderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString();
                                
                                if(Directory.Exists(source))
                                {
                                    Directory.Move(tempDump + subfolderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString(), errorDump + "\\" + subfolderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString());

                                }

                            }
                            else
                            {
                                string source = tempDump + subfolderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString();

                                if (Directory.Exists(source))
                                {
                                    Directory.Move(tempDump + subfolderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString(), backupDump + "\\" + subfolderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString());

                                }

                                string backupFolder = backupDump + "\\" + subfolderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString();
                                createTargetFile(backupFolder);
                            }
                            
                            uniqueSeqId = uniqueSeqId + 1;
                            File.WriteAllText(ConfigurationManager.AppSettings["UniqueRefCounterFileLocation"], uniqueSeqId.ToString());

                        }

                        List<string> loosePages = Directory.GetFiles(sMonitorFolder).ToList();
                        if(loosePages.Count!=0)
                        {
                            string dest=null;
                            
                            foreach (var loosePage in loosePages)
                            {
                                 dest = tempDump + "LoosePage_" + uniqueSeqId ;
                                if(!Directory.Exists(dest))
                                {
                                    Directory.CreateDirectory(dest);
                                }
                                File.Move(loosePage, tempDump  + "LoosePage_" + uniqueSeqId + "\\" + loosePage.Split('\\').Last());
                                
                            }
                            Directory.Move(dest, errorDump+"\\"+dest.Split('\\').Last());
                            uniqueSeqId = uniqueSeqId + 1;
                            File.WriteAllText(ConfigurationManager.AppSettings["UniqueRefCounterFileLocation"], uniqueSeqId.ToString());

                        }

                    }

                    else
                    {
                        log.LogFileWrite(DateTime.Now+ " : Incorrect Monitoring folder given : "+ sMonitorFolder, ConfigurationManager.AppSettings["watcherLogFileLocation"]);
                    }
                }
            }
            catch (Exception ex)
            {
                log.LogFileWrite(DateTime.Now+" : Exception " + ex.Message, ConfigurationManager.AppSettings["watcherLogFileLocation"]);
            }

            
            
        }

        #endregion


        #region process folders
        public void processFolder(string folderPath)
        {
            try
            {
                #region finding which types of files to Monitor
                //Adding up all file types in a list from Config file
                var fileExtensions = new List<string>();
                var fileTypes = ConfigurationManager.GetSection("FileType") as NameValueCollection;
                if (fileTypes.Count == 0)
                {
                    log.LogFileWrite(DateTime.Now+" : No value given in FileType Section inside APP.Config", ConfigurationManager.AppSettings["watcherLogFileLocation"]);
                }
                else
                {
                    foreach (var key in fileTypes.AllKeys)
                    {
                        fileExtensions.Add(fileTypes[key]);
                    }
                }
                #endregion

                

                //Checking for any subfolders inside a folder
                string[] subSubFolder=Directory.GetDirectories(folderPath);

                if (subSubFolder.Length==0)
                {
                    //Getting list of all files
                    List<string> filesPaths = new List<string>();
                    filesPaths = Directory.GetFiles(folderPath).ToList();
                    //checking for Null Folder
                    if (filesPaths.Count() != 0)
                    {
                        foreach (var filePath in filesPaths)
                        {
                            string extentionForFile = Path.GetExtension(filePath);
                            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(filePath);

                            //if File Type is one of the files to Monitor then proceed or go to Else
                            if (fileExtensions.Contains(extentionForFile))
                            {
                                if (extentionForFile == ".xml")
                                {
                                    //xmlProvided = true;
                                    noOfInputXML = noOfInputXML + 1;
                                    if(noOfInputXML>1)
                                    {
                                        moveToErrorDump = true;
                                    }
                                    if (!Directory.Exists(tempDump + folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString()))
                                    {
                                        Directory.CreateDirectory(tempDump+folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString());
                                    }
                                    File.Move(filePath, tempDump + folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString() + "\\" + fileNameWithoutExtension + extentionForFile);

                                }
                                else
                                {
                                    log.LogFileWrite(DateTime.Now + " : Processing File " + filePath.Split('\\').Last(), logFileLocation);
                                    if (!Directory.Exists(tempDump + folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString()))
                                    {
                                        Directory.CreateDirectory(tempDump+folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString());
                                    }
                                    File.Move(filePath, tempDump + folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString() + "\\" + fileNameWithoutExtension + extentionForFile);

                                }

                            }

                            //File Type to monitor not defined in Config File
                            else
                            {
                                log.LogFileWrite(DateTime.Now + " : Invalid file Extension", logFileLocation);
                                //Directory.Move(folderPath, errorDump+ folderPath.Split('\\').Last() + "_" + uniqueSeqId);
                                if (!Directory.Exists(tempDump + folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString()))
                                {
                                    Directory.CreateDirectory(folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString());
                                }
                                File.Move(filePath, tempDump + folderPath.Split('\\').Last() + "_" + uniqueSeqId.ToString() + "\\" + fileNameWithoutExtension + extentionForFile);
                                moveToErrorDump = true;


                            }
                        }

                        //if (noOfInputXML > 1)
                        //{
                        //    correctInputXML = false;
                        //}
                        //else
                        //{
                        //    correctInputXML = true;
                        //}

                    }

                    else
                    {
                        log.LogFileWrite(DateTime.Now + " : No files Present inside " + folderPath, logFileLocation);
                        Directory.Move(folderPath, errorDump + "\\" + folderPath.Split('\\').Last() + "_" + uniqueSeqId);
                        
                        uniqueSeqId = uniqueSeqId + 1;
                        File.WriteAllText(ConfigurationManager.AppSettings["UniqueRefCounterFileLocation"], uniqueSeqId.ToString());

                        //nullFolder = true;

                    }
                }

                else
                {
                    moveToErrorDump = true;
                    Directory.Move(folderPath,errorDump+"\\"+folderPath.Split('\\').Last()+"_"+uniqueSeqId);
                    uniqueSeqId = uniqueSeqId + 1;
                    File.WriteAllText(ConfigurationManager.AppSettings["UniqueRefCounterFileLocation"], uniqueSeqId.ToString());

                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                if(Directory.Exists(folderPath))
                {
                    Directory.Delete(folderPath);
                }
               
                
            }
        }
        #endregion

        

        #region Target File Creation 
        public void createTargetFile(string inputFileLocation)
        {
            try
            {
                string[] xmlFiles = Directory.GetFiles(inputFileLocation, "*.xml");

                if(xmlFiles.Length==0)
                {
                    // string targetFilePath = Path.GetDirectoryName(inputFileLocation);
                    XmlSerializer TargetXMLObj = new XmlSerializer(typeof(ImportSession));
                    ImportSession mappingTargetFileObj = new ImportSession();
                    mappingTargetFileObj.Batches = new ImportSessionBatches();
                    mappingTargetFileObj.Batches.Batch = new ImportSessionBatchesBatch();

                    //Mapping data for Target File
                    mappingTargetFileObj.Batches.Batch.BatchName = "Test";
                    mappingTargetFileObj.Batches.Batch.Priority = Int32.Parse(BatchPriority);
                    mappingTargetFileObj.Batches.Batch.BatchClassName = BatchClassName;

                    mappingTargetFileObj.Batches.BatchFields = new ImportSessionBatchesBatchFields();


                    mappingTargetFileObj.Batches.BatchFields.B_FABSOFT_UNIQUE_ID = B_CHANNEL;
                    mappingTargetFileObj.Batches.BatchFields.B_FABSOFT_XML_DATETIME = B_BULK_INGESTION_XML_DATETIME;
                    mappingTargetFileObj.Batches.BatchFields.B_MFD_DEVICE_NAME = B_BULK_INGESTION_SYTEM_NAME;
                    mappingTargetFileObj.Batches.BatchFields.B_MFD_IP_ADDRESS = B_BULK_INGESTION_IP_ADDRESS;
                    mappingTargetFileObj.Batches.BatchFields.B_MFD_USER_ID = B_BULK_INGESTION_USER_ID;

                    mappingTargetFileObj.Batches.Documents = new ImportSessionBatchesDocuments();
                    mappingTargetFileObj.Batches.Documents.FormTypeName = FormName2;

                    mappingTargetFileObj.Batches.Documents.IndexFields = new ImportSessionBatchesDocumentsIndexFields();

                    mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_DATETIME = D_MFD_DOC_DATETIME;
                    mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_FORM_ID = D_MFD_DOC_FORM_ID;
                    mappingTargetFileObj.Batches.BatchFields.B_MFD_SERIAL_NO = B_BULK_INGESTION_SERIAL_NO;
                    mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_BRANCH_NO = D_MFD_DOC_BRANCH_NO;
                    mappingTargetFileObj.Batches.Documents.Pages = this.FindAllDocuments(inputFileLocation);


                    swr = new StreamWriter(inputFileLocation + "\\Target.trg");
                    TargetXMLObj.Serialize(swr, mappingTargetFileObj);

                }

                else if(xmlFiles.Length==1)
                {
                    //Deserializing input XML
                    XmlSerializer deserializingMetadataXML = new XmlSerializer(typeof(MetaData));
                    sr = new StreamReader(xmlFiles[0]);
                    MetaData InputXMLObj = (MetaData)deserializingMetadataXML.Deserialize(sr);


                   // string targetFilePath = Path.GetDirectoryName(inputFileLocation);
                    XmlSerializer TargetXMLObj = new XmlSerializer(typeof(ImportSession));
                    ImportSession mappingTargetFileObj = new ImportSession();
                    mappingTargetFileObj.Batches = new ImportSessionBatches();
                    mappingTargetFileObj.Batches.Batch = new ImportSessionBatchesBatch();


                    //Mapping data for Target File
                    mappingTargetFileObj.Batches.Batch.BatchName = "Test";
                    mappingTargetFileObj.Batches.Batch.Priority = Int32.Parse(BatchPriority);
                    mappingTargetFileObj.Batches.Batch.BatchClassName = BatchClassName;

                    mappingTargetFileObj.Batches.BatchFields = new ImportSessionBatchesBatchFields();

                    if(InputXMLObj.BatchPropertyFields.B_CHANNEL==null )
                    {
                        
                        mappingTargetFileObj.Batches.BatchFields.B_FABSOFT_UNIQUE_ID = B_CHANNEL;

                    }
                    else if(InputXMLObj.BatchPropertyFields.B_CHANNEL == "")
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_FABSOFT_UNIQUE_ID = B_CHANNEL;
                    }
                    else
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_FABSOFT_UNIQUE_ID = InputXMLObj.BatchPropertyFields.B_CHANNEL;

                    }


                    if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_XML_DATETIME ==null)
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_FABSOFT_XML_DATETIME = B_BULK_INGESTION_XML_DATETIME;

                    }
                    else if(InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_XML_DATETIME == "")
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_FABSOFT_XML_DATETIME = B_BULK_INGESTION_XML_DATETIME;

                    }
                    else
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_FABSOFT_XML_DATETIME = InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_XML_DATETIME;

                    }



                    if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_SYTEM_NAME == null)
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_DEVICE_NAME = B_BULK_INGESTION_SYTEM_NAME;

                    }
                    else if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_SYTEM_NAME == "")
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_DEVICE_NAME = B_BULK_INGESTION_SYTEM_NAME;

                    }
                    else
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_DEVICE_NAME = InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_SYTEM_NAME;

                    }


                    if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_IP_ADDRESS == null)
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_IP_ADDRESS = B_BULK_INGESTION_IP_ADDRESS;

                    }
                    else if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_IP_ADDRESS == "")
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_IP_ADDRESS = B_BULK_INGESTION_IP_ADDRESS;

                    }
                    else
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_IP_ADDRESS = InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_IP_ADDRESS;

                    }

                    if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_SERIAL_NO == null)
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_SERIAL_NO = B_BULK_INGESTION_SERIAL_NO;

                    }
                    else if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_SERIAL_NO == "")
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_SERIAL_NO = B_BULK_INGESTION_SERIAL_NO;

                    }
                    else
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_SERIAL_NO = InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_SERIAL_NO;

                    }

                    if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_USER_ID == null)
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_USER_ID = B_BULK_INGESTION_USER_ID;

                    }
                   else if (InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_USER_ID == "")
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_USER_ID = B_BULK_INGESTION_USER_ID;

                    }
                    else
                    {
                        mappingTargetFileObj.Batches.BatchFields.B_MFD_USER_ID = InputXMLObj.BatchPropertyFields.B_BULK_INGESTION_USER_ID;

                    }




                    mappingTargetFileObj.Batches.Documents = new ImportSessionBatchesDocuments();
                    mappingTargetFileObj.Batches.Documents.FormTypeName = FormName2;

                    mappingTargetFileObj.Batches.Documents.IndexFields = new ImportSessionBatchesDocumentsIndexFields();

                    if(InputXMLObj.IndexPropertyFileds.D_MFD_DOC_DATETIME==null)
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_DATETIME = D_MFD_DOC_DATETIME;
                    }
                    else if (InputXMLObj.IndexPropertyFileds.D_MFD_DOC_DATETIME == "")
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_DATETIME = D_MFD_DOC_DATETIME;
                    }
                    else
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_DATETIME = InputXMLObj.IndexPropertyFileds.D_MFD_DOC_DATETIME;

                    }

                    if(InputXMLObj.IndexPropertyFileds.D_MFD_DOC_FORM_ID==null)
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_FORM_ID = D_MFD_DOC_FORM_ID;
                    }
                    else if (InputXMLObj.IndexPropertyFileds.D_MFD_DOC_FORM_ID == "")
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_FORM_ID = D_MFD_DOC_FORM_ID;
                    }
                    else
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_FORM_ID = InputXMLObj.IndexPropertyFileds.D_MFD_DOC_FORM_ID;

                    }

                    if (InputXMLObj.IndexPropertyFileds.D_MFD_DOC_ACCT_NO == null)
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_FORM_ID = D_MFD_DOC_FORM_ID;
                    }
                    else if (InputXMLObj.IndexPropertyFileds.D_MFD_DOC_FORM_ID == "")
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_ACCT_NO = D_MFD_DOC_ACCT_NO ;
                    }
                    else
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_ACCT_NO = InputXMLObj.IndexPropertyFileds.D_MFD_DOC_ACCT_NO;
                    }

                    if(InputXMLObj.IndexPropertyFileds.D_MFD_DOC_BRANCH_NO==null)
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_BRANCH_NO = D_MFD_DOC_BRANCH_NO;
                    }
                    else if(InputXMLObj.IndexPropertyFileds.D_MFD_DOC_BRANCH_NO == "")
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_BRANCH_NO = D_MFD_DOC_BRANCH_NO;
                    }
                    else
                    {
                        mappingTargetFileObj.Batches.Documents.IndexFields.D_MFD_DOC_BRANCH_NO = InputXMLObj.IndexPropertyFileds.D_MFD_DOC_BRANCH_NO;

                    }


                    mappingTargetFileObj.Batches.Documents.Pages = this.FindAllDocuments(inputFileLocation);

                    
                     swr = new StreamWriter(inputFileLocation + "\\Target.trg");
                    TargetXMLObj.Serialize(swr, mappingTargetFileObj);


                }
                else
                {
                    sr.Dispose();
                    Directory.Move(inputFileLocation, errorDump+ "\\" + inputFileLocation.Split('\\').Last());
                }
                
                    
               

                

            }
            catch(Exception e)
            {
                sr.Dispose();
                log.LogFileWrite(DateTime.Now+" : Target File Method Error: "+e.Message,logFileLocation);
                Directory.Move(inputFileLocation+"\\", errorDump + "\\" + inputFileLocation.Split('\\').Last());


            }
            finally
            {
                sr.Dispose();
                swr.Dispose();
            }

        }

        private string[] FindAllDocuments(string inputFileLocation)
        {
            string tempMonitoringFolder = Path.GetDirectoryName(inputFileLocation);
            string[] ImportFileName;
            List<string> ImportFileNames = new List<string>();
            List<string> files=Directory.GetFiles(inputFileLocation).Where(name => !name.EndsWith(".xml")).ToList();
            if (files.Any())
            {
                foreach (var file in files)
                {

                    ImportFileNames.Add(file);

                }
                ImportFileName = ImportFileNames.ToArray();
                return ImportFileName;
            }
            else
            {
                log.LogFileWrite("No files present other than the Input file in Folder", logFileLocation);
                return ImportFileName=null;
            }
            
        }


        #endregion

        
        #region finding Consumer and allocating values
        public void findConsumer(string folderPath)
        {
            //string extentionForFile = Path.GetExtension(filepath);
            
            String[] substrings = folderPath.Split('\\');
            int flag = 0;
            foreach (var substring in substrings)
            {
                if (substring.Contains(ConfigurationManager.AppSettings["ConsumerKeyWord"]))
                {
                    ConsumerName = substrings[flag];
                    log.LogFileWrite(DateTime.Now+ " : Consumer Name : " + ConsumerName,logFileLocation);
                }
                else
                {
                    flag++;
                }


            }

            var customerData = new List<string>();
            var Consumer = ConfigurationManager.GetSection(ConsumerName) as NameValueCollection;
            if (Consumer.Count == 0)
            {
                log.LogFileWrite(DateTime.Now+" : Invalid Section",logFileLocation);
            }
            else
            {
                foreach (var key in Consumer.AllKeys)
                {
                    customerData.Add(Consumer[key]);
                }
            }

            backupDump = customerData[0];
            errorDump = customerData[1];
            monitoringfolder = customerData[2];
            logFileLocation = customerData[3];

            BatchClassName = customerData[4];
            BatchPriority = customerData[5];
            FormName1 = customerData[6];

            //Batch Property
            B_CHANNEL = customerData[7];
            B_BULK_INGESTION_XML_DATETIME = customerData[8];
            B_BULK_INGESTION_SYTEM_NAME = customerData[9];

            B_BULK_INGESTION_IP_ADDRESS = customerData[10];
            B_BULK_INGESTION_SERIAL_NO = customerData[11];
            B_BULK_INGESTION_USER_ID = customerData[12];

            //Document Property
            FormName2 = customerData[13];

            //Index Property Field
            D_MFD_DOC_DATETIME = customerData[14];
            D_MFD_DOC_FORM_ID = customerData[15];
            D_MFD_DOC_ACCT_NO = customerData[16];
            D_MFD_DOC_BRANCH_NO = customerData[17];





        }
        #endregion

        





    }
}
