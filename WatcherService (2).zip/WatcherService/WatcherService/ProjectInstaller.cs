﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Threading.Tasks;

namespace WatcherService
{
    [RunInstallerAttribute(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
            
            
        }
       
        
            
            public static int Main()
            {
            // Creates a new installer.
            ProjectInstaller myNewProjectInstaller = new ProjectInstaller();

                // Gets the attributes for the collection.
                AttributeCollection attributes = TypeDescriptor.GetAttributes(myNewProjectInstaller);

                /* Prints whether to run the installer by retrieving the 
                 * RunInstallerAttribute from the AttributeCollection. */
                RunInstallerAttribute myAttribute =
                   (RunInstallerAttribute)attributes[typeof(RunInstallerAttribute)];
                Console.WriteLine("Run the installer? " + myAttribute.RunInstaller.ToString());

                return 0;
            
        }
       
    }
}
