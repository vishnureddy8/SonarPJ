﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WatcherService
{
    /// <summary>
    ///  This interface used to log the message.
    /// </summary>
    public interface ILogger
    {
        /// <summary>
        /// This method used to log the exception messages thrown by the class.
        /// </summary>
        /// <param name="message">Exception message thrown by the class.</param>
        void LogMessage(string message);
    }
}
