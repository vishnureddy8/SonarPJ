﻿using System;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Text;

namespace WatcherService.Helper
{


    /// <summary>
    ///  This class used to log the error message.
    /// </summary>
    public class ErrorLogger : ILogger
    {
        /// <summary>
        /// Variable for LastLine.
        /// </summary>
        private string lastline = "**************************";

        /// <summary>
        /// Variable for LogFileLocation.
        /// </summary>
        private string logFileLocation;

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the ErrorLogger class.
        /// </summary>
        public ErrorLogger()
        {
            this.logFileLocation = ConfigurationManager.AppSettings["ConfigWatcherServiceLogFileLocation"];
        }

        #endregion

        #region public method

        /// <summary>
        /// This method used to log the exception messages thrown by the class.
        /// </summary>
        /// <param name="message">Exception message thrown by the class.</param>
        public void LogMessage(string message)
        {
            StringBuilder logMessage = new StringBuilder();
            logMessage.Append(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss", CultureInfo.CurrentCulture));
            logMessage.Append("     ");
            logMessage.AppendLine(message);
            logMessage.AppendLine(this.lastline);

            File.AppendAllText(this.logFileLocation, logMessage.ToString());
        }

        #endregion

    }
}
